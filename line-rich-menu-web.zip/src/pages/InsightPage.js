// InsightPage.js

import React from 'react';
import { Box, Typography } from '@mui/material';
export default function InsightPage() {
  return (
    <Box sx={{ p: 1 }}>
      <Typography variant="h4">Insight</Typography>
      <Typography>ข้อมูล Insight ของคุณ</Typography>
    </Box>
  );
}
